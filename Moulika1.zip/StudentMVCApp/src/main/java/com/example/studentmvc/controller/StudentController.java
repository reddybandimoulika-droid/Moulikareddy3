package com.example.studentmvc.controller;

import com.example.studentmvc.model.Student;
import com.example.studentmvc.repository.StudentRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class StudentController {
    private final StudentRepository repo;

    public StudentController(StudentRepository repo) {
        this.repo = repo;
    }

    @GetMapping("/")
    public String home(Model model) throws Exception {
        model.addAttribute("students", repo.findAll());
        model.addAttribute("student", new Student());
        return "index";
    }

    @PostMapping("/students")
    public String save(@ModelAttribute Student student) throws Exception {
        repo.save(student);
        return "redirect:/";
    }

    @GetMapping("/students/edit/{id}")
    public String edit(@PathVariable int id, Model model) throws Exception {
        model.addAttribute("student", repo.findById(id));
        model.addAttribute("students", repo.findAll());
        return "edit";
    }

    @PostMapping("/students/update")
    public String update(@ModelAttribute Student student) throws Exception {
        repo.update(student);
        return "redirect:/";
    }

    @GetMapping("/students/delete/{id}")
    public String delete(@PathVariable int id) throws Exception {
        repo.delete(id);
        return "redirect:/";
    }
}
