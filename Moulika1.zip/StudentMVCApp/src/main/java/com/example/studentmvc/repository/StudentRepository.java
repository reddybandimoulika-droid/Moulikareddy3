package com.example.studentmvc.repository;

import com.example.studentmvc.model.Student;
import org.springframework.stereotype.Repository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class StudentRepository {
    private final String url = "jdbc:mysql://localhost:3306/college";
    private final String user = "root";
    private final String password = "YOUR_MYSQL_PASSWORD";

    private Connection connection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    public List<Student> findAll() throws SQLException {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT id, name, age, course FROM students ORDER BY id DESC";
        try (Connection con = connection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                students.add(new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age"),
                    rs.getString("course")
                ));
            }
        }
        return students;
    }

    public void save(Student s) throws SQLException {
        String sql = "INSERT INTO students(name, age, course) VALUES (?, ?, ?)";
        try (Connection con = connection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setInt(2, s.getAge());
            ps.setString(3, s.getCourse());
            ps.executeUpdate();
        }
    }

    public void update(Student s) throws SQLException {
        String sql = "UPDATE students SET name=?, age=?, course=? WHERE id=?";
        try (Connection con = connection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setInt(2, s.getAge());
            ps.setString(3, s.getCourse());
            ps.setInt(4, s.getId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM students WHERE id=?";
        try (Connection con = connection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public Student findById(int id) throws SQLException {
        String sql = "SELECT id, name, age, course FROM students WHERE id=?";
        try (Connection con = connection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Student(rs.getInt("id"), rs.getString("name"),
                        rs.getInt("age"), rs.getString("course"));
                }
            }
        }
        return null;
    }
}
