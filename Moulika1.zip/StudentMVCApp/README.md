# Student MVC Application

A beginner-friendly Java MVC full-stack application using:
- Java 17
- Spring Boot MVC
- Thymeleaf frontend
- JDBC
- MySQL
- Maven

## Setup

1. Install JDK 17+, Maven, and MySQL.
2. Run `database.sql` in MySQL.
3. Open `src/main/java/com/example/studentmvc/repository/StudentRepository.java`.
4. Replace `YOUR_MYSQL_PASSWORD` with your MySQL password.
5. Run:
   `mvn spring-boot:run`
6. Open:
   `http://localhost:8080`

Features: Add, View, Edit, Delete students.

Architecture:
Frontend (HTML/CSS) -> Controller -> Repository/JDBC -> MySQL
